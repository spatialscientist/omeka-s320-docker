<?php declare(strict_types=1);

namespace IiifServer\Iiif\Exception;

class RuntimeException extends \RuntimeException implements ExceptionInterface
{
}
