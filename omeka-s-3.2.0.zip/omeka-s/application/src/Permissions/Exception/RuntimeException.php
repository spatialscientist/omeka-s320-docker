<?php
namespace Omeka\Permissions\Exception;

class RuntimeException extends \RuntimeException implements ExceptionInterface
{
}
